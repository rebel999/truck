package com.capgemini.truckbooking.client;

import java.sql.Date;
import java.time.LocalDate;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

import com.capgemini.truckbooking.bean.BookingBean;
import com.capgemini.truckbooking.bean.TruckBean;
import com.capgemini.truckbooking.bookingexception.BookingException;
import com.capgemini.truckbooking.dao.ITruckDao;
import com.capgemini.truckbooking.dao.TruckDao;
import com.capgemini.truckbooking.service.ITruckService;
import com.capgemini.truckbooking.service.TruckService;
import com.capgemini.truckbooking.util.Validator;

public class Client {

	private static Scanner scanner=new Scanner(System.in);
	private static ITruckService truckService= new TruckService();
	private static ITruckDao truckDao=new TruckDao();

	public static void main(String[] args) throws BookingException {

		while(true) {
			System.out.println();
			System.out.println();
			System.out.println("1.Book Truck");
			System.out.println("2.Exit");

			int choice=scanner.nextInt();

			switch(choice) {

			case 1: System.out.println("enter customer id : ");
			String custId=scanner.next();

			List<TruckBean> truckList=truckService.retrieveAllTrucks();
			showTrucks(truckList);

			System.out.println("enter truck id from above list : ");
			int truckId=scanner.nextInt();
			System.out.println("enter no. of trucks to be booked : ");
			int noOfTrucks=scanner.nextInt();
			if(truckService.isTruckExist(noOfTrucks,truckId)) {
				System.out.println("enter mobile number");
				Long custMobile=scanner.nextLong();
				System.out.println("enter date of transport as yyyy-MM-dd");
				String date=scanner.next();
				if(Validator.validateDate(date)){
					String dateParts[] = date.split("-");
					LocalDate dateformat=LocalDate.of(Integer.parseInt(dateParts[0]), Integer.parseInt(dateParts[1]), Integer.parseInt(dateParts[2])); 
					if(dateformat.isAfter(LocalDate.now())){

						BookingBean bookingBean=new BookingBean();
						bookingBean.setCustId(custId);
						bookingBean.setCustMobile(custMobile);
						bookingBean.setTruckId(truckId);
						bookingBean.setNoOfTrucks(noOfTrucks);
						bookingBean.setDateOfTransport(dateformat);
						if(truckService.addBookingDetails(bookingBean)){
							//retrieving the booking id from table
							Integer bookingid=truckService.retrieveBookingId(bookingBean);
							System.out.println("booking id: "+bookingid);
							boolean success=truckService.updateNoOfTrucks(noOfTrucks);
							
						}else{
							System.out.println("fail");
						}


					}else{
						System.out.println("enter valid input date(not today's date)");
					}
				}else{
					System.out.println("please enter correct date format");
				}


			}else{
				System.out.println("Required no. of trucks are not available;");
			}






			}



		}



	}

	private static void showTrucks(List<TruckBean> truckList) {
		/*Iterator<TruckBean> iterator = truckList.iterator();
		while(iterator.hasNext()) {
			System.out.println(iterator.next());}*/
		
		for(TruckBean t: truckList){
			System.out.println(t);
		}
		

	}



}
