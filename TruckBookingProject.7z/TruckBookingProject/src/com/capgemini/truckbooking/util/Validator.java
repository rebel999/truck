package com.capgemini.truckbooking.util;

public class Validator {

	public static boolean validateDate(String dateString) {
		return dateString.matches("[1-2][0-9]{3}[-]([1-9]|0[1-9]|1[0-2])[-]([1-9]|0[1-9]|1[0-9]|2[0-9]|3[0-1])");
	} 
	public static boolean validateCustId(String custId){
		return custId.matches("[A-Z]{1}[0-9]{6}");
	}
}
