package com.capgemini.truckbooking.bookingexception;

public class BookingException extends Exception{

	private String message;

	public BookingException() {
		super();
	}
	
	public BookingException(String message) {
		super();
		this.message = message;
	}
	
	public String getMessage() {
		return message;
	}

	@Override
	public String toString() {
		return "BookingException [message=" + message + "]";
	}

	
	/*public BookingException(String arg0, Throwable arg1, boolean arg2,boolean arg3) {
		super(arg0,arg1,arg2,arg3);*/
	}

