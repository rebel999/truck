package com.capgemini.truckbooking.service;

import java.util.List;

import com.capgemini.truckbooking.bean.BookingBean;
import com.capgemini.truckbooking.bean.TruckBean;
import com.capgemini.truckbooking.bookingexception.BookingException;
import com.capgemini.truckbooking.dao.ITruckDao;
import com.capgemini.truckbooking.dao.TruckDao;

public class TruckService implements ITruckService{

	ITruckDao truckDao= new TruckDao();
	
	
	@Override
	public List<TruckBean> retrieveAllTrucks() throws BookingException {
		
		return truckDao.retrieveAllTrucks();
	}


	@Override
	public boolean isTruckExist(int noOfTrucks, int truckId) {
		// TODO Auto-generated method stub
		return truckDao.isTruckExist(noOfTrucks,truckId);
	}


	@Override
	public boolean addBookingDetails(BookingBean bookingBean) {
		
		return truckDao.addBookingDetails(bookingBean);
	}


	@Override
	public Integer retrieveBookingId(BookingBean bookingBean) {
		// TODO Auto-generated method stub
		return truckDao.retrieveBookingId(bookingBean);
	}


	@Override
	public boolean updateNoOfTrucks(int noOfTrucks) {
		// TODO Auto-generated method stub
		return truckDao.updateNoOfTrucks(noOfTrucks);
	}


}
