package com.capgemini.truckbooking.bean;

import java.time.LocalDate;

public class BookingBean {
	private Integer bookingId;
	private String custId;
	private Long custMobile;
	private Integer truckId;
	private Integer noOfTrucks;
	private LocalDate dateOfTransport;
	
	public BookingBean() {
		super();
	}

	public BookingBean(Integer bookingId, String custId, Long custMobile,
			Integer truckId, Integer noOfTrucks, LocalDate dateOfTransport) {
		super();
		this.bookingId = bookingId;
		this.custId = custId;
		this.custMobile = custMobile;
		this.truckId = truckId;
		this.noOfTrucks = noOfTrucks;
		this.dateOfTransport = dateOfTransport;
	}

	public Integer getBookingId() {
		return bookingId;
	}

	public void setBookingId(Integer bookingId) {
		this.bookingId = bookingId;
	}

	public String getCustId() {
		return custId;
	}

	public void setCustId(String custId) {
		this.custId = custId;
	}

	public Long getCustMobile() {
		return custMobile;
	}

	public void setCustMobile(Long custMobile) {
		this.custMobile = custMobile;
	}

	public Integer getTruckId() {
		return truckId;
	}

	public void setTruckId(Integer truckId) {
		this.truckId = truckId;
	}

	public Integer getNoOfTrucks() {
		return noOfTrucks;
	}

	public void setNoOfTrucks(Integer noOfTrucks) {
		this.noOfTrucks = noOfTrucks;
	}

	public LocalDate getDateOfTransport() {
		return dateOfTransport;
	}

	public void setDateOfTransport(LocalDate dateOfTransport) {
		this.dateOfTransport = dateOfTransport;
	}

	@Override
	public String toString() {
		return "BookingBean [bookingId=" + bookingId + ", custId=" + custId
				+ ", custMobile=" + custMobile + ", truckId=" + truckId
				+ ", noOfTrucks=" + noOfTrucks + ", dateOfTransport="
				+ dateOfTransport + "]";
	}

	
	
	
	

}
