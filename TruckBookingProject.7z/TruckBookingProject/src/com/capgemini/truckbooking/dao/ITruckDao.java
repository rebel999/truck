package com.capgemini.truckbooking.dao;

import java.util.List;

import com.capgemini.truckbooking.bean.BookingBean;
import com.capgemini.truckbooking.bean.TruckBean;
import com.capgemini.truckbooking.bookingexception.BookingException;

public interface ITruckDao {

	public List<TruckBean> retrieveAllTrucks() throws BookingException;

	public boolean isTruckExist(int noOfTrucks, int truckId);

	public boolean addBookingDetails(BookingBean bookingBean);

	public Integer retrieveBookingId(BookingBean bookingBean);

	public boolean updateNoOfTrucks(int noOfTrucks);

	
}
