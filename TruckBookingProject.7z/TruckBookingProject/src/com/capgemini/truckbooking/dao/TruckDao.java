package com.capgemini.truckbooking.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.capgemini.truckbooking.bean.BookingBean;
import com.capgemini.truckbooking.bean.TruckBean;
import com.capgemini.truckbooking.bookingexception.BookingException;
import com.capgemini.truckbooking.util.DBConnection;

public class TruckDao implements ITruckDao{

	@Override
	public List<TruckBean> retrieveAllTrucks() throws BookingException {
		
		String sql="select * from truckdetails";
		int truckCount=0;
		try(
				Connection connection=DBConnection.getConnection();
				Statement statement=connection.createStatement();
				) {
			ResultSet resultSet=statement.executeQuery(sql);
			List<TruckBean> truckList=new ArrayList<>();
			while(resultSet.next()) {
				truckCount++;
				TruckBean truck=new TruckBean();
				populateTrucks(truck,resultSet);
				truckList.add(truck);
			}
			return truckList;
			
		} catch (SQLException  e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}catch(Exception e) {
			e.printStackTrace();
		}
		return null;
	}

	private void populateTrucks(TruckBean truck, ResultSet resultSet) throws SQLException {
		
		truck.setTruckId(resultSet.getInt("truckid"));
		truck.setTruckType(resultSet.getString("trucktype"));
		truck.setOrigin(resultSet.getString("origin"));
		truck.setDestination(resultSet.getString("destination"));
		truck.setCharges(resultSet.getFloat("charges"));
		truck.setAvailableNos(resultSet.getInt("availablenos"));
	}

	@Override
	public boolean isTruckExist(int noOfTrucks,int truckId) {
		String sql="select availablenos from truckdetails where truckid=?";
		try(
				Connection connection=DBConnection.getConnection();
				PreparedStatement pst=connection.prepareStatement(sql);
				) {
			pst.setInt(1, truckId);
			ResultSet rs= pst.executeQuery();
			while(rs.next()) {
				if(rs.getInt("availablenos")>=noOfTrucks)
				return true;
				else
					return false;
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return false;
	}

	@Override
	public boolean addBookingDetails(BookingBean bookingBean) {
		String sql="insert into bookingdetails values(booking_id_seq.nextval,?,?,?,?,?)";
		try(
				Connection connection=DBConnection.getConnection();
				PreparedStatement pst=connection.prepareStatement(sql);
				) {
			pst.setString(1, bookingBean.getCustId());
			pst.setLong(2, bookingBean.getCustMobile());
			pst.setInt(3, bookingBean.getTruckId());
			pst.setInt(4, bookingBean.getNoOfTrucks());
			pst.setDate(5,Date.valueOf(bookingBean.getDateOfTransport())) ;
			int n=pst.executeUpdate();
			if(n>0){
				return true;
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return false;
	}

	@Override
	public Integer retrieveBookingId(BookingBean bookingBean) {
		String sql="select bookingid from bookingdetails where custId=? ";
		try(
				Connection connection=DBConnection.getConnection();
				PreparedStatement pst=connection.prepareStatement(sql);
				) {
			pst.setString(1, bookingBean.getCustId());
			 ResultSet rs=pst.executeQuery();
			 if(rs.next()){
				 bookingBean.setBookingId(rs.getInt(1));
				 return bookingBean.getBookingId();
			 }
			
			
		} catch (SQLException | BookingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		return null;
	}

	@Override
	public boolean updateNoOfTrucks(int noOfTrucks) {
		String sql="update truckdetails set availableNos=availableNos-?";
		try(
				Connection connection=DBConnection.getConnection();
				PreparedStatement pst=connection.prepareStatement(sql);
				) {
			
			pst.setInt(1, noOfTrucks);
			int n=pst.executeUpdate();
			if(n!=0){
				return true;
			}
			
		} catch (SQLException | BookingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return false;
	}

}
