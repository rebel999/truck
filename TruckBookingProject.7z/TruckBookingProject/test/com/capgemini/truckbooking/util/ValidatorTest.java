package com.capgemini.truckbooking.util;

import static org.junit.Assert.*;

import org.junit.Test;

public class ValidatorTest {

	@Test
	public void testValidateDate() {
		//fail("Not yet implemented");
		assertTrue(new Validator().validateDate("2018-11-15"));
		
	}
	
	@Test
	public void testNotValidateDate() {
		//fail("Not yet implemented");
		assertFalse(new Validator().validateDate("13-11-2018"));
		
	}

	@Test
	public void testValidateCustId() {
		//fail("Not yet implemented");
		assertTrue(new Validator().validateCustId("A111111"));
	}
	
	@Test
	public void testNotValidateCustId() {
		//fail("Not yet implemented");
		assertFalse(new Validator().validateCustId("AZ111111"));
	}

}
